package com.doer.calculator.service;

import java.util.Scanner;

import com.doer.calculator.common.Calculator;

public class OddNumberSum extends Calculator {

	@Override
	public int calculate() {
		// Method for getting sum of odd numbers between start number to end number
		int sum = 0;
		for (int i = getStartNum(); i <= getEndNum(); i++) {
			//
			if (i % 2 != 0) {
				sum += i;
			}
		}
		return sum;
	}

	@Override
	public void takeInput(Scanner scanner) {
		
		log.info("Enter Your first Number");
		int startNum = scanner.nextInt();
		log.info("Enter Your end Number");
		int endNum = scanner.nextInt();

		// Set numbers
		setStartNum(startNum);
		setEndNum(endNum);
	}

}
