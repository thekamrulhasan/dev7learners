package com.doer.calculator.service;

import java.util.Scanner;

import com.doer.calculator.common.Calculator;

public class SeriesNumberSum extends Calculator {

	 int seriesNum;
	
	@Override
	public int calculate() {
		int sum = 0;
		for (int i = getStartNum(); i <= getEndNum(); i += seriesNum) {
			sum += i;
		}
		return sum;
	}

	@Override
	public void takeInput(Scanner scanner) {
		// TODO Auto-generated method stub
		log.info("Enter Your first Number");
		int startNum = scanner.nextInt();
		log.info("Enter Your end Number");
		int endNum = scanner.nextInt();
		log.info("Enter Your Series Number");
		seriesNum = scanner.nextInt();
		
		setStartNum(startNum);
		setEndNum(endNum);

	}

}
