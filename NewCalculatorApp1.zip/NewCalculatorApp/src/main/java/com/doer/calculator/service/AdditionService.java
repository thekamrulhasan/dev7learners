package com.doer.calculator.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.doer.calculator.common.Calculator;
import com.doer.calculator.main.CalculatorApp;

public class AdditionService extends Calculator {

	int sum = 0;
	int num;

	@Override
	public int calculate() {
		Scanner scanner = new Scanner(System.in);
		while (getStartNum() != 0) {
			sum += getStartNum();
			log.info("Enter Your next Number");
			num = scanner.nextInt();
			setStartNum(num);
			
		}
		return sum;
	}

	@Override
	public void takeInput(Scanner scanner) {

		log.info("Enter Your First Number");
		 num = scanner.nextInt();
		setStartNum(num);
	}
}
