package com.doer.calculator.common;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.doer.calculator.main.CalculatorApp;

public abstract class Calculator {
	
	public static Logger log = Logger.getLogger(CalculatorApp.class);
	private int startNum;
	private int endNum;
	private int number;

	public int calculate() {
		return 0;
	} 
	
	public void takeInput(Scanner scanner) {
		 
	}
	
	public int getStartNum() {
		return startNum;
	}
	public void setStartNum(int startNUm) {
		this.startNum = startNUm;
	}
	public int getEndNum() {
		return endNum;
	}
	public void setEndNum(int endNum) {
		this.endNum = endNum;
	}
	
	
}
