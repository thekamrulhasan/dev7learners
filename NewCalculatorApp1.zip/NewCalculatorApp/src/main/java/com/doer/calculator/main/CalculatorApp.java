package com.doer.calculator.main;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.doer.calculator.common.Calculator;
import com.doer.calculator.service.AdditionService;
import com.doer.calculator.service.CalculationService;
import com.doer.calculator.service.DivisionService;
import com.doer.calculator.service.EvenNumberSum;
import com.doer.calculator.service.MultiplicationService;
import com.doer.calculator.service.OddNumberSum;
import com.doer.calculator.service.SeriesNumberSum;
import com.doer.calculator.service.SubstractionService;

public class CalculatorApp {

	static Logger log = Logger.getLogger(CalculatorApp.class);

	// Method for choosing option to get an operation
	public static Calculator selectCalculatorService(int selectedOpt) {

		switch (selectedOpt) {

		case 0:
			log.info("Your App has been closed");
			System.exit(0);

			// case for addition
		case 1:
			Calculator addition = new AdditionService();
			return addition;

		// case for subtraction
		case 2:
			Calculator subtruction = new SubstractionService();
			return subtruction;

		// case for Multiplication
		case 3:
			Calculator multiplication = new MultiplicationService();
			return multiplication;

		// case for Division
		case 4:
			Calculator division = new DivisionService();
			return division;

		// case for Calculate sum, subtraction, Multiplication and division
		case 5:
			Calculator allInOne = new CalculationService();
			return allInOne;

		// case for getting the sum of odd numbers
		case 6:
			Calculator oddNumberSum = new OddNumberSum();
			return oddNumberSum;

		// case for getting sum of even numbers
		case 7:
			Calculator evenNumberSum = new EvenNumberSum();
			return evenNumberSum;

		// case for getting sum of series numbers
		case 8:
			Calculator seriesNumberSum = new SeriesNumberSum();
			return seriesNumberSum;

		default:
			System.out.println("Enter a valid Number");
			return null;
		}

	}

	public static int chooseOperation(Scanner scanner) {

		log.info("\nChoose operator: 1 = Addition,  2 = Substruction, 3 = Multiplication,  4 = Division,  5 = Calculation");
		log.info("6 = Sum of Odd numbers  7 = Sum of even numbers   8 = Sum of series numbers  0 = result");
		int selectedOpteration = scanner.nextInt();
		return selectedOpteration;
	}

	// Method for getting repeatative calculation
	
	public static void getCalculation() {
		Scanner scanner = new Scanner(System.in);
		int selectedOpteration = chooseOperation(scanner);
		Calculator calculator = selectCalculatorService(selectedOpteration);
		calculator.takeInput(scanner);
		int result = calculator.calculate();
		log.info("Result is " + result);
		getCalculation();
	}

	public static void main(String[] args) {

		getCalculation();
	}

}
