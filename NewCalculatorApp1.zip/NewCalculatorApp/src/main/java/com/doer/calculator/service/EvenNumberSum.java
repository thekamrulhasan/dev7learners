package com.doer.calculator.service;

import java.util.Scanner;

import com.doer.calculator.common.Calculator;

public class EvenNumberSum extends Calculator {

	@Override
	public int calculate() {
		// Method for Getting Sum between start number to end number
		int sum = 0;
		for (int i = getStartNum(); i <= getEndNum(); i++) {
			if (i % 2 == 0) {
				sum += i;
			}
		}
		return sum;
	}

	@Override
	public void takeInput(Scanner scanner) {
		// TODO Auto-generated method stub
		log.info("Enter Your first Number");
		int startNum = scanner.nextInt();
		log.info("Enter Your end Number");
		int endNum = scanner.nextInt();

		setStartNum(startNum);
		setEndNum(endNum);
	}

}
