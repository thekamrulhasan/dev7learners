package com.doer.calculator.service;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.doer.calculator.common.Calculator;
import com.doer.calculator.main.CalculatorApp;

public class CalculationService extends Calculator {

	int result;
	int num;
	int operators;

	// Method for getting Calculation
	@Override
	public int calculate() {
		Scanner scanner = new Scanner(System.in);

		while (operators != 0) {
			switch (operators) {
			case 1:
				result += num;
				break;
			case 2:
				result -= num;
				break;
			case 3:
				result *= num;
				break;

			case 4:
				result /= num;
				break;

			}
			// input for getting operator
			log.info("Choose operator: 1= +, 2 = -, 3 = *, 4 = /, 0 = result");
			operators = scanner.nextInt();

			// getting result
			if (operators != 0) {
				log.info("Enter next Number");
				num = scanner.nextInt();
			}
			if (operators < 0 || operators > 4) {
				log.info("Please enter a valid Number");
				log.info("Choose operator: 1= +, 2 = -, 3 = * 4 = /");
				operators = scanner.nextInt();
			}

		}
		return result;
	}

	// method for taking input
	@Override
	public void takeInput(Scanner scanner) {

		log.info("Enter Your First Number");
		num = scanner.nextInt();
		result = num;
		log.info("Choose operator: 1= +, 2 = -, 3 = *, 4 = /");
		operators = scanner.nextInt();
		log.info("Enter Your next Number");
		num = scanner.nextInt();
	}

}
