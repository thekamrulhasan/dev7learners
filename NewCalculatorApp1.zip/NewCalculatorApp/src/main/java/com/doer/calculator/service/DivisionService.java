package com.doer.calculator.service;

import java.util.Scanner;

import com.doer.calculator.common.Calculator;

public class DivisionService extends Calculator {

	@Override
	public int calculate() {
		// Division code here
		return getStartNum() / getEndNum();
	}

	@Override
	public void takeInput(Scanner scanner) {
		// TODO Auto-generated method stub

		log.info("Enter Your first Number");
		int startNum = scanner.nextInt();
		log.info("Enter Your end Number");
		int endNum = scanner.nextInt();
		setStartNum(startNum);
		setEndNum(endNum);
	}

}
