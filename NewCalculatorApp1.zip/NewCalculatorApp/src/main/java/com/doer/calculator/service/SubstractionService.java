package com.doer.calculator.service;

import java.util.Scanner;

import com.doer.calculator.common.Calculator;

public class SubstractionService extends Calculator {

	@Override
	public int calculate() {
		// TODO Auto-generated method stub
		return getStartNum() - getEndNum();
	}

	@Override
	public void takeInput(Scanner scanner) {
		log.info("Enter Your first Number");
		int startNum = scanner.nextInt();
		log.info("Enter Your end Number");
		int endNum = scanner.nextInt();
		setStartNum(startNum);
		setEndNum(endNum);

	}

}
